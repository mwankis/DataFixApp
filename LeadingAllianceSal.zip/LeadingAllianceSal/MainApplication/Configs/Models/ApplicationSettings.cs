﻿namespace MainApplication.Configs.Models
{
    public class ApplicationSettings
    {
        public DynamicsConnections DynamicsConnections { get; set; }

        public Task3ApiDetails Task3ApiDetails { get; set; }
    }
}
