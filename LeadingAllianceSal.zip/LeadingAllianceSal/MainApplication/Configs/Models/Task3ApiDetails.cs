﻿namespace MainApplication.Configs.Models
{
    public class Task3ApiDetails
    {
        public string SdURL { get; set; }

        public string SdUser { get; set; }

        public string SdPassword { get; set; }
    }
}
