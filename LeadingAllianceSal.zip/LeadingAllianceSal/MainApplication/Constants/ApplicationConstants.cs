﻿namespace MainApplication.Constants
{
    public static class ApplicationConstants
    {
        public static string ApplicationSettingsFileName { get; set; } = "applicationsettings.json";
    }
}
