﻿using System;

namespace MainApplication.Task1.Models
{
    public class DictionaryKey
    {
        public Guid Customer { get; set; }

        public Guid Card { get; set; }

        public DateTime DateTime { get; set; }
    }
}
