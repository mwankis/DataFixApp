﻿using System;

namespace MainApplication.Task6_DuplicateAddDeduct.Models
{
    public class DictionaryKey
    {
        public Guid CustomerId { get; set; }

        public DateTime Date { get; set; }

        public int Points { get; set; }

        public string new_additiondeduction { get; set; }
    }
}
