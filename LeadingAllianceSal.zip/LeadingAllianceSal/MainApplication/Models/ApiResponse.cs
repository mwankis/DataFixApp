﻿namespace MainApplication.Models
{
    public class ApiResponse
    {
        public string ErrorMessage { get; set; }

        public object ResponseBody { get; set; }
    }
}
